import React, { Component } from "react";

export default class Home extends Component {
    
render() {
    return (
        <h2>You are not logged in</h2>
    )
}
}