import React, { Component } from "react";

export default class Login extends Component {
    
render() {
    return (
        <h2>You are in Login Page</h2>
    )
}
}